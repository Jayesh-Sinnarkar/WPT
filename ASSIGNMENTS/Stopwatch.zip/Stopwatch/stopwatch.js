let timer;
    let isRunning = false;
    let startTime;
    let elapsedTime = 0;
    let flagCount = 0;

    function formatTime(milliseconds) {
        const date = new Date(milliseconds);
        const hours = date.getUTCHours().toString().padStart(2, '0');
        const minutes = date.getUTCMinutes().toString().padStart(2, '0');
        const seconds = date.getUTCSeconds().toString().padStart(2, '0');
        const millisecondsStr = date.getUTCMilliseconds().toString().padStart(3, '0');
        return `${hours}:${minutes}:${seconds}.<span class="small ">${millisecondsStr}</span>`;
    }

    function updateStopwatch() {
        const currentTime = new Date().getTime();
        const deltaTime = currentTime - startTime + elapsedTime;
        $("#stopwatch").html(formatTime(deltaTime));
    }

    $("#toggle").on("click", function () {
        if (!isRunning) {
            startTime = new Date().getTime();
            timer = setInterval(updateStopwatch, 10);
            isRunning = true;
            $("#toggle").removeClass("btn-lightpink").addClass("btn-warning");
            $("#start").removeClass("fa-play").addClass("fa-pause")
        } else {
            clearInterval(timer);
            elapsedTime += new Date().getTime() - startTime;
            isRunning = false;
            $("#toggle").removeClass("btn-warning").addClass("btn-success");
            $("#start").removeClass("fa-pause").addClass("fa-play")
        }
    });

    $("#restart").on("click", function () {
        clearInterval(timer);
        isRunning = false;
        elapsedTime = 0;
        $("#stopwatch").html("00:00:00<span class='small'>.00</span>");
        $("#toggle").removeClass("btn-warning").addClass("btn-success");
        $("#start").removeClass("fa-pause").addClass("fa-play")
        $("#flaggedTimes").text("").addClass("hidden");


    });

    $("#flag").on("click", function () {
        const flagTime = formatTime(new Date().getTime() - startTime);
        flagCount++;
        $("#flaggedTimes").removeClass("hidden").append(`<div>Flag${flagCount}: ${flagTime}</div>`);
    });